-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Creato il: Dic 22, 2018 alle 15:51
-- Versione del server: 5.7.24
-- Versione PHP: 7.2.10-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pixpresenze`
--
CREATE DATABASE IF NOT EXISTS `pixpresenze` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pixpresenze`;

-- --------------------------------------------------------

--
-- Struttura della tabella `presenze_contratti`
--

DROP TABLE IF EXISTS `presenze_contratti`;
CREATE TABLE `presenze_contratti` (
  `id` int(11) NOT NULL,
  `descrizione` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `presenze_orari`
--

DROP TABLE IF EXISTS `presenze_orari`;
CREATE TABLE `presenze_orari` (
  `id` int(11) NOT NULL,
  `descrizione` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `presenze_orelavorate`
--

DROP TABLE IF EXISTS `presenze_orelavorate`;
CREATE TABLE `presenze_orelavorate` (
  `id` int(11) NOT NULL,
  `anno` varchar(4) DEFAULT NULL,
  `id_personale` int(11) DEFAULT NULL,
  `annocorrente` decimal(10,2) DEFAULT NULL,
  `mesecorrente` decimal(6,2) DEFAULT NULL,
  `gennaio` decimal(6,2) DEFAULT NULL,
  `febbraio` decimal(6,2) DEFAULT NULL,
  `marzo` decimal(6,2) DEFAULT NULL,
  `aprile` decimal(6,2) DEFAULT NULL,
  `maggio` decimal(6,2) DEFAULT NULL,
  `giugno` decimal(6,2) DEFAULT NULL,
  `luglio` decimal(6,2) DEFAULT NULL,
  `agosto` decimal(6,2) DEFAULT NULL,
  `settembre` decimal(6,2) DEFAULT NULL,
  `ottobre` decimal(6,2) DEFAULT NULL,
  `novembre` decimal(6,2) DEFAULT NULL,
  `dicembre` decimal(6,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `presenze_personale`
--

DROP TABLE IF EXISTS `presenze_personale`;
CREATE TABLE `presenze_personale` (
  `id` int(10) UNSIGNED NOT NULL,
  `codice_op` varchar(50) NOT NULL,
  `nominativo` varchar(200) NOT NULL,
  `cod_fisc` varchar(16) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `id_inps` varchar(50) NOT NULL,
  `id_tipo_orario` int(10) UNSIGNED NOT NULL,
  `id_tipo_contratto` int(10) UNSIGNED NOT NULL,
  `ore_maturate` int(11) NOT NULL,
  `ore_giornaliere` decimal(8,2) NOT NULL,
  `operativo` tinyint(1) NOT NULL,
  `presente` tinyint(1) DEFAULT '0',
  `inpausa` tinyint(1) DEFAULT '0',
  `assuntoil` date DEFAULT NULL,
  `dimessoil` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `presenze_presenze`
--

DROP TABLE IF EXISTS `presenze_presenze`;
CREATE TABLE `presenze_presenze` (
  `id` int(10) UNSIGNED NOT NULL,
  `codice_op` int(10) UNSIGNED NOT NULL,
  `data_ora` timestamp NULL DEFAULT NULL,
  `id_azione` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `presenze_utenti`
--

DROP TABLE IF EXISTS `presenze_utenti`;
CREATE TABLE `presenze_utenti` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cognome` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tipoutente` tinyint(2) NOT NULL,
  `lastaccess` timestamp NULL DEFAULT NULL,
  `dataultimamodifica` timestamp NULL DEFAULT NULL,
  `operatore` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `presenze_contratti`
--
ALTER TABLE `presenze_contratti`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `presenze_orari`
--
ALTER TABLE `presenze_orari`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `presenze_orelavorate`
--
ALTER TABLE `presenze_orelavorate`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `presenze_personale`
--
ALTER TABLE `presenze_personale`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codice_op` (`codice_op`);

--
-- Indici per le tabelle `presenze_presenze`
--
ALTER TABLE `presenze_presenze`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `presenze_utenti`
--
ALTER TABLE `presenze_utenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `presenze_contratti`
--
ALTER TABLE `presenze_contratti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT per la tabella `presenze_orari`
--
ALTER TABLE `presenze_orari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT per la tabella `presenze_orelavorate`
--
ALTER TABLE `presenze_orelavorate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `presenze_personale`
--
ALTER TABLE `presenze_personale`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT per la tabella `presenze_presenze`
--
ALTER TABLE `presenze_presenze`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT per la tabella `presenze_utenti`
--
ALTER TABLE `presenze_utenti`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
